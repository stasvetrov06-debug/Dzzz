﻿

IF DB_ID(N'AromaDom') IS NOT NULL
BEGIN
    ALTER DATABASE [AromaDom] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [AromaDom];
END
GO
CREATE DATABASE [AromaDom];
GO
USE [AromaDom];
GO

/* ------------------------------ Таблица типов материалов ------------------------------ */
CREATE TABLE dbo.MaterialTypes
(
    MaterialTypeId INT             IDENTITY(1,1) NOT NULL,
    MaterialTypeName NVARCHAR(100) NOT NULL,
    LossPercent    DECIMAL(5,2)    NOT NULL CONSTRAINT CK_MaterialTypes_LossPercent CHECK (LossPercent >= 0),
    CONSTRAINT PK_MaterialTypes PRIMARY KEY CLUSTERED (MaterialTypeId),
    CONSTRAINT UQ_MaterialTypes_Name UNIQUE (MaterialTypeName)
);
GO

/* ------------------------------ Таблица материалов ------------------------------ */
CREATE TABLE dbo.Materials
(
    MaterialId       INT             IDENTITY(1,1) NOT NULL,
    MaterialTypeId   INT             NOT NULL,
    MaterialName     NVARCHAR(150)   NOT NULL,
    UnitPrice        DECIMAL(12,2)   NOT NULL CONSTRAINT CK_Materials_UnitPrice CHECK (UnitPrice >= 0),
    MeasurementUnit  NVARCHAR(20)    NOT NULL,
    PackageQuantity  DECIMAL(12,3)   NOT NULL CONSTRAINT CK_Materials_PackageQuantity CHECK (PackageQuantity >= 0),
    StockQuantity    DECIMAL(12,3)   NOT NULL CONSTRAINT CK_Materials_StockQuantity CHECK (StockQuantity >= 0),
    MinimumQuantity  DECIMAL(12,3)   NOT NULL CONSTRAINT CK_Materials_MinimumQuantity CHECK (MinimumQuantity >= 0),
    CONSTRAINT PK_Materials PRIMARY KEY CLUSTERED (MaterialId),
    CONSTRAINT UQ_Materials_Name UNIQUE (MaterialName),
    CONSTRAINT FK_Materials_MaterialTypes FOREIGN KEY (MaterialTypeId)
        REFERENCES dbo.MaterialTypes (MaterialTypeId)
);
GO

/* ------------------------------ Таблица типов продукции ------------------------------ */
CREATE TABLE dbo.ProductTypes
(
    ProductTypeId   INT             IDENTITY(1,1) NOT NULL,
    ProductTypeName NVARCHAR(100)   NOT NULL,
    Coefficient     DECIMAL(6,3)    NOT NULL CONSTRAINT CK_ProductTypes_Coefficient CHECK (Coefficient > 0),
    CONSTRAINT PK_ProductTypes PRIMARY KEY CLUSTERED (ProductTypeId),
    CONSTRAINT UQ_ProductTypes_Name UNIQUE (ProductTypeName)
);
GO

/* ------------------------------ Таблица продукции ------------------------------ */
CREATE TABLE dbo.Products
(
    ProductId     INT             IDENTITY(1,1) NOT NULL,
    ProductTypeId INT             NOT NULL,
    Article       NVARCHAR(20)    NOT NULL,
    ProductName   NVARCHAR(150)   NOT NULL,
    MinPartnerPrice DECIMAL(12,2) NOT NULL CONSTRAINT CK_Products_MinPartnerPrice CHECK (MinPartnerPrice >= 0),
    CONSTRAINT PK_Products PRIMARY KEY CLUSTERED (ProductId),
    CONSTRAINT UQ_Products_Article UNIQUE (Article),
    CONSTRAINT UQ_Products_Name UNIQUE (ProductName),
    CONSTRAINT FK_Products_ProductTypes FOREIGN KEY (ProductTypeId)
        REFERENCES dbo.ProductTypes (ProductTypeId)
);
GO

/* ------------------ Таблица рецептур (материалы продукции) ------------------ */
CREATE TABLE dbo.MaterialProducts
(
    MaterialProductId INT           IDENTITY(1,1) NOT NULL,
    MaterialId        INT           NOT NULL,
    ProductId         INT           NOT NULL,
    QuantityPerUnit   DECIMAL(12,4) NOT NULL CONSTRAINT CK_MaterialProducts_Quantity CHECK (QuantityPerUnit >= 0),
    CONSTRAINT PK_MaterialProducts PRIMARY KEY CLUSTERED (MaterialProductId),
    CONSTRAINT UQ_MaterialProducts UNIQUE (MaterialId, ProductId),
    CONSTRAINT FK_MaterialProducts_Materials FOREIGN KEY (MaterialId)
        REFERENCES dbo.Materials (MaterialId),
    CONSTRAINT FK_MaterialProducts_Products FOREIGN KEY (ProductId)
        REFERENCES dbo.Products (ProductId)
);
GO


/* ==================== Загрузка данных импорта ==================== */

SET IDENTITY_INSERT dbo.MaterialTypes ON;
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (1, N'Соевый воск', 0.12);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (2, N'Пчелиный воск', 0.18);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (3, N'Ароматическое масло', 0.25);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (4, N'Краситель', 0.08);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (5, N'Фитиль', 0.03);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (6, N'Стеклянная тара', 0.04);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (7, N'Керамическая тара', 0.06);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (8, N'Декор', 0.10);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (9, N'Упаковка', 0.05);
INSERT INTO dbo.MaterialTypes (MaterialTypeId, MaterialTypeName, LossPercent) VALUES (10, N'Этикетка', 0.02);
SET IDENTITY_INSERT dbo.MaterialTypes OFF;
GO

SET IDENTITY_INSERT dbo.Materials ON;
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (1, 1, N'Соевый воск премиум', 890.00, N'кг', 20.000, 120.000, 40.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (2, 1, N'Соевый воск EcoBlend', 760.00, N'кг', 25.000, 95.000, 30.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (3, 2, N'Пчелиный воск натуральный', 1450.00, N'кг', 10.000, 48.000, 15.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (4, 3, N'Масло лаванды', 3200.00, N'л', 1.000, 18.500, 6.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (5, 3, N'Масло ванили', 2950.00, N'л', 1.000, 22.000, 8.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (6, 3, N'Масло цитрусовое', 2870.00, N'л', 1.000, 16.700, 5.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (7, 4, N'Краситель янтарный', 640.00, N'кг', 0.500, 6.200, 2.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (8, 4, N'Краситель розовый', 615.00, N'кг', 0.500, 5.100, 1.500);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (9, 5, N'Фитиль хлопковый 8 см', 4.50, N'шт', 500.000, 2500.000, 800.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (10, 5, N'Фитиль хлопковый 12 см', 5.80, N'шт', 400.000, 1800.000, 600.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (11, 6, N'Стакан прозрачный 200 мл', 28.00, N'шт', 100.000, 950.000, 300.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (12, 6, N'Стакан матовый 250 мл', 34.00, N'шт', 60.000, 620.000, 200.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (13, 7, N'Чаша керамическая белая', 72.00, N'шт', 40.000, 280.000, 80.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (14, 8, N'Сухоцветы лаванды', 520.00, N'кг', 0.300, 4.800, 1.500);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (15, 9, N'Лента сатиновая бежевая', 12.00, N'м', 50.000, 340.000, 120.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (16, 9, N'Коробка подарочная малая', 18.00, N'шт', 50.000, 420.000, 150.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (17, 10, N'Этикетка фирменная круглая', 3.20, N'шт', 250.000, 1800.000, 500.000);
INSERT INTO dbo.Materials (MaterialId, MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit, PackageQuantity, StockQuantity, MinimumQuantity) VALUES (18, 10, N'Наклейка предупреждающая', 2.10, N'шт', 200.000, 1600.000, 400.000);
SET IDENTITY_INSERT dbo.Materials OFF;
GO

SET IDENTITY_INSERT dbo.ProductTypes ON;
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (1, N'Классическая свеча', 1.000);
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (2, N'Премиальная свеча', 1.150);
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (3, N'Подарочный набор', 1.300);
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (4, N'Интерьерная свеча', 1.200);
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (5, N'Мини-свеча', 0.800);
INSERT INTO dbo.ProductTypes (ProductTypeId, ProductTypeName, Coefficient) VALUES (6, N'Сезонная коллекция', 1.250);
SET IDENTITY_INSERT dbo.ProductTypes OFF;
GO

SET IDENTITY_INSERT dbo.Products ON;
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (1, 1, N'AR-001', N'Свеча «Лавандовый вечер»', 980.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (2, 1, N'AR-002', N'Свеча «Ванильный крем»', 950.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (3, 1, N'AR-003', N'Свеча «Цитрусовый сад»', 970.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (4, 2, N'AR-004', N'Свеча «Белый мускус»', 1290.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (5, 2, N'AR-005', N'Свеча «Дикая орхидея»', 1360.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (6, 4, N'AR-006', N'Свеча «Теплый янтарь»', 1490.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (7, 4, N'AR-007', N'Свеча «Сандаловое дерево»', 1520.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (8, 5, N'AR-008', N'Мини-свеча «Лаванда»', 420.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (9, 5, N'AR-009', N'Мини-свеча «Ваниль»', 410.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (10, 5, N'AR-010', N'Мини-свеча «Цитрус»', 430.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (11, 3, N'AR-011', N'Набор «Уютный дом»', 2190.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (12, 3, N'AR-012', N'Набор «Теплый вечер»', 2340.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (13, 6, N'AR-013', N'Свеча «Зимние специи»', 1380.00);
INSERT INTO dbo.Products (ProductId, ProductTypeId, Article, ProductName, MinPartnerPrice) VALUES (14, 6, N'AR-014', N'Свеча «Хвойный лес»', 1410.00);
SET IDENTITY_INSERT dbo.Products OFF;
GO

SET IDENTITY_INSERT dbo.MaterialProducts ON;
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (1, 1, 1, 0.1800);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (2, 4, 1, 0.0090);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (3, 9, 1, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (4, 11, 1, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (5, 17, 1, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (6, 1, 2, 0.1800);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (7, 5, 2, 0.0100);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (8, 9, 2, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (9, 11, 2, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (10, 17, 2, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (11, 2, 3, 0.1750);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (12, 6, 3, 0.0110);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (13, 9, 3, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (14, 11, 3, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (15, 17, 3, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (16, 1, 4, 0.2200);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (17, 5, 4, 0.0060);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (18, 10, 4, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (19, 12, 4, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (20, 17, 4, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (21, 1, 5, 0.2250);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (22, 4, 5, 0.0040);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (23, 10, 5, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (24, 12, 5, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (25, 17, 5, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (26, 3, 6, 0.2800);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (27, 7, 6, 0.0040);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (28, 10, 6, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (29, 13, 6, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (30, 17, 6, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (31, 3, 7, 0.2850);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (32, 5, 7, 0.0030);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (33, 10, 7, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (34, 13, 7, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (35, 17, 7, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (36, 2, 8, 0.0700);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (37, 4, 8, 0.0030);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (38, 9, 8, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (39, 11, 8, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (40, 2, 9, 0.0700);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (41, 5, 9, 0.0030);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (42, 9, 9, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (43, 11, 9, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (44, 2, 10, 0.0700);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (45, 6, 10, 0.0030);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (46, 9, 10, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (47, 11, 10, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (48, 1, 11, 0.1800);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (49, 4, 11, 0.0090);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (50, 9, 11, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (51, 11, 11, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (52, 15, 11, 1.2000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (53, 16, 11, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (54, 17, 11, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (55, 1, 12, 0.2250);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (56, 5, 12, 0.0100);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (57, 10, 12, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (58, 12, 12, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (59, 15, 12, 1.5000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (60, 16, 12, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (61, 17, 12, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (62, 1, 13, 0.2100);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (63, 5, 13, 0.0080);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (64, 7, 13, 0.0030);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (65, 10, 13, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (66, 12, 13, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (67, 18, 13, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (68, 1, 14, 0.2150);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (69, 6, 14, 0.0040);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (70, 7, 14, 0.0020);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (71, 10, 14, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (72, 12, 14, 1.0000);
INSERT INTO dbo.MaterialProducts (MaterialProductId, MaterialId, ProductId, QuantityPerUnit) VALUES (73, 18, 14, 1.0000);
SET IDENTITY_INSERT dbo.MaterialProducts OFF;
GO


CREATE OR ALTER VIEW dbo.vw_MaterialsRequired AS
SELECT m.MaterialId,
       CAST(SUM(mp.QuantityPerUnit) AS DECIMAL(12,2)) AS RequiredQuantity
FROM dbo.Materials m
LEFT JOIN dbo.MaterialProducts mp ON mp.MaterialId = m.MaterialId
GROUP BY m.MaterialId;
GO

USE master;
GO