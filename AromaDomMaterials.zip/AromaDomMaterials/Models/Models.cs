namespace AromaDomMaterials.Models;

/// <summary>Материал, отображаемый в списке на главной форме.</summary>
public class Material
{
    public int MaterialId { get; set; }
    public int MaterialTypeId { get; set; }
    public string MaterialTypeName { get; set; } = string.Empty;
    public string MaterialName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public string MeasurementUnit { get; set; } = string.Empty;
    public decimal PackageQuantity { get; set; }
    public decimal StockQuantity { get; set; }
    public decimal MinimumQuantity { get; set; }

    /// <summary>Требуемое количество: сумма объёма материала по всем продуктам его рецептур.</summary>
    public decimal RequiredQuantity { get; set; }
}

/// <summary>Элемент справочника «Тип материала».</summary>
public class MaterialType
{
    public int MaterialTypeId { get; set; }
    public string MaterialTypeName { get; set; } = string.Empty;
}

/// <summary>Продукция, в рецептуре которой используется материал.</summary>
public class ProductUsage
{
    public string Article { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductTypeName { get; set; } = string.Empty;
    public decimal QuantityPerUnit { get; set; }
}
