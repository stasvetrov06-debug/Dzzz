using AromaDomMaterials.Data;
using AromaDomMaterials.Models;
using AromaDomMaterials.UI;

namespace AromaDomMaterials;

/// <summary>
/// Форма списка продукции, в рецептуре которой используется выбранный материал,
/// с указанием наименования продукции и необходимого количества материала.
/// </summary>
public class ProductListForm : Form
{
    private readonly DataGridView grid;
    private readonly Label emptyStateLabel;

    public ProductListForm(Material material)
    {
        Text = "Продукция, использующая материал";
        ClientSize = new Size(820, 480);
        MinimumSize = new Size(700, 380);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Theme.PrimaryBackground;
        Font = Theme.CreateFont(10f);
        Icon = FormIconLoader.Load();

        var headerPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 84,
            BackColor = Theme.SecondaryBackground,
            Padding = new Padding(16)
        };

        var titleLabel = new Label
        {
            Text = $"Продукция с материалом «{material.MaterialName}»",
            Font = Theme.CreateFont(14f, FontStyle.Bold),
            ForeColor = Theme.AccentColor,
            Location = new Point(16, 12),
            AutoSize = true
        };
        var subtitleLabel = new Label
        {
            Text = $"Тип материала: {material.MaterialTypeName}    ·    " +
                   $"Требуемое количество: {material.RequiredQuantity:0.00} {material.MeasurementUnit}",
            Font = Theme.CreateFont(9f),
            ForeColor = Theme.TextColor,
            Location = new Point(18, 46),
            AutoSize = true
        };

        var backButton = new Button
        {
            Text = "← Назад к списку материалов",
            Size = new Size(230, 40),
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        Theme.StyleBackButton(backButton);
        backButton.Click += (_, _) => Close();
        headerPanel.Resize += (_, _) =>
            backButton.Location = new Point(headerPanel.ClientSize.Width - backButton.Width - 16, (headerPanel.Height - backButton.Height) / 2);

        headerPanel.Controls.AddRange([titleLabel, subtitleLabel, backButton]);

        // ---------- Таблица продукции ----------
        grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            BackgroundColor = Theme.PrimaryBackground,
            BorderStyle = BorderStyle.None,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            Font = Theme.CreateFont(10f),
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        };
        grid.DefaultCellStyle.BackColor = Theme.PrimaryBackground;
        grid.DefaultCellStyle.ForeColor = Theme.TextColor;
        grid.DefaultCellStyle.SelectionBackColor = Theme.SecondaryBackground;
        grid.DefaultCellStyle.SelectionForeColor = Theme.TextColor;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Theme.SecondaryBackground;
        grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.AccentColor;
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.AccentTextColor;
        grid.ColumnHeadersDefaultCellStyle.Font = Theme.CreateFont(10f, FontStyle.Bold);
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.ColumnHeadersHeight = 34;

        emptyStateLabel = new Label
        {
            Text = "Для этого материала нет продукции:\nв рецептурах продукции он не используется.",
            Font = Theme.CreateFont(11f),
            ForeColor = Theme.TextColor,
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Fill,
            Visible = false
        };

        var footerPanel = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 48,
            BackColor = Theme.SecondaryBackground,
            Padding = new Padding(16, 10, 16, 8)
        };
        var footerHint = new Label
        {
            Text = "Количество материала указано на одну единицу продукции.",
            Font = Theme.CreateFont(8.5f, FontStyle.Italic),
            ForeColor = Theme.TextColor,
            AutoSize = true
        };
        footerPanel.Controls.Add(footerHint);

        Controls.Add(grid);
        Controls.Add(emptyStateLabel);
        Controls.Add(footerPanel);
        Controls.Add(headerPanel);
        headerPanel.BringToFront();
        backButton.Location = new Point(headerPanel.ClientSize.Width - backButton.Width - 16, (headerPanel.Height - backButton.Height) / 2);

        Load += (_, _) => LoadProducts(material);
    }

    /// <summary>Загружает список продукции для материала из базы данных.</summary>
    private void LoadProducts(Material material)
    {
        try
        {
            List<ProductUsage> products = AppDatabase.GetProductsByMaterial(material.MaterialId);

            grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(ProductUsage.Article),
                HeaderText = "Артикул",
                FillWeight = 20
            });
            grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(ProductUsage.ProductTypeName),
                HeaderText = "Тип продукции",
                FillWeight = 30
            });
            grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(ProductUsage.ProductName),
                HeaderText = "Наименование продукции",
                FillWeight = 40
            });
            grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(ProductUsage.QuantityPerUnit),
                HeaderText = $"Необходимое количество, {material.MeasurementUnit}",
                FillWeight = 30,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "0.####" }
            });

            grid.DataSource = products;
            emptyStateLabel.Visible = products.Count == 0;
            grid.Visible = products.Count > 0;
        }
        catch (Exception ex)
        {
            MainForm.ShowDatabaseError("не удалось загрузить список продукции", ex);
            Close();
        }
    }
}
