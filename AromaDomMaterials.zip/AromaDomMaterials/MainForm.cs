using System.Drawing.Drawing2D;
using AromaDomMaterials.Data;
using AromaDomMaterials.Models;
using AromaDomMaterials.UI;

namespace AromaDomMaterials;

/// <summary>
/// Главная форма: список материалов в карточном виде, добавление и редактирование,
/// переход к списку продукции, использующей материал.
/// </summary>
public class MainForm : Form
{
    private readonly FlowLayoutPanel cardsPanel;
    private readonly Panel headerPanel;

    public MainForm()
    {
        Text = "Арома Дом — Учёт материалов";
        ClientSize = new Size(1000, 640);
        MinimumSize = new Size(860, 520);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.PrimaryBackground;
        Font = Theme.CreateFont(10f);
        Icon = LoadAppIcon();

        // ---------- Шапка: логотип компании и заголовок ----------
        headerPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 96,
            BackColor = Theme.SecondaryBackground,
            Padding = new Padding(16, 10, 16, 10)
        };

        var logoPictureBox = new PictureBox
        {
            Size = new Size(76, 76),
            Location = new Point(16, 10),
            SizeMode = PictureBoxSizeMode.Zoom,
            Image = LoadLogo(),
            // Логотип не искажается: сохраняются пропорции изображения.
            BackColor = Color.Transparent
        };

        var titleLabel = new Label
        {
            Text = "Арома Дом",
            Font = Theme.CreateFont(20f, FontStyle.Bold),
            ForeColor = Theme.AccentColor,
            AutoSize = true,
            Location = new Point(110, 18)
        };
        var subtitleLabel = new Label
        {
            Text = "Подсистема учёта материалов производства декоративных ароматических свечей",
            Font = Theme.CreateFont(10f),
            ForeColor = Theme.TextColor,
            AutoSize = true,
            Location = new Point(112, 56)
        };

        var addButton = new Button
        {
            Text = "＋ Добавить материал",
            Size = new Size(210, 42),
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        Theme.StyleAccentButton(addButton);
        addButton.Click += (_, _) => AddMaterial();

        headerPanel.Controls.AddRange([logoPictureBox, titleLabel, subtitleLabel, addButton]);
        headerPanel.Resize += (_, _) =>
            addButton.Location = new Point(headerPanel.ClientSize.Width - addButton.Width - 16, (headerPanel.Height - addButton.Height) / 2);

        // ---------- Список материалов в карточном виде ----------
        cardsPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            Padding = new Padding(16),
            WrapContents = true
        };

        Controls.Add(cardsPanel);
        Controls.Add(headerPanel);
        headerPanel.BringToFront();

        Load += (_, _) =>
        {
            addButton.Location = new Point(headerPanel.ClientSize.Width - addButton.Width - 16, (headerPanel.Height - addButton.Height) / 2);
            RefreshMaterialList();
        };
    }

    /// <summary>Обновляет список карточек материалов данными из базы данных.</summary>
    private void RefreshMaterialList()
    {
        try
        {
            cardsPanel.SuspendLayout();
            cardsPanel.Controls.Clear();

            List<Material> materials = AppDatabase.GetMaterials();
            if (materials.Count == 0)
            {
                cardsPanel.Controls.Add(new Label
                {
                    Text = "В базе данных нет материалов.\nНажмите кнопку «Добавить материал», чтобы создать первую запись.",
                    Font = Theme.CreateFont(11f),
                    ForeColor = Theme.TextColor,
                    AutoSize = true,
                    Margin = new Padding(12)
                });
                return;
            }

            foreach (Material material in materials)
            {
                cardsPanel.Controls.Add(CreateMaterialCard(material));
            }
        }
        catch (Exception ex)
        {
            ShowDatabaseError("не удалось загрузить список материалов", ex);
        }
        finally
        {
            cardsPanel.ResumeLayout();
        }
    }

    /// <summary>Создаёт карточку материала: тип, наименование, минимум, остаток, цена, требуемое количество.</summary>
    private Control CreateMaterialCard(Material material)
    {
        var card = new Panel
        {
            Size = new Size(300, 208),
            Margin = new Padding(10),
            BackColor = Theme.SecondaryBackground,
            Cursor = Cursors.Hand
        };

        var nameColor = material.StockQuantity < material.MinimumQuantity ? Color.Firebrick : Theme.AccentColor;

        var typeLabel = new Label
        {
            Text = material.MaterialTypeName,
            Font = Theme.CreateFont(9f),
            ForeColor = Theme.TextColor,
            Location = new Point(14, 12),
            AutoSize = true
        };
        var nameLabel = new Label
        {
            Text = material.MaterialName,
            Font = Theme.CreateFont(11f, FontStyle.Bold),
            ForeColor = nameColor,
            Location = new Point(14, 34),
            Size = new Size(272, 38)
        };
        var detailsLabel = new Label
        {
            Text = $"Минимальное количество: {material.MinimumQuantity:0.##} {material.MeasurementUnit}\n" +
                   $"Количество на складе: {material.StockQuantity:0.##} {material.MeasurementUnit}\n" +
                   $"Цена: {material.UnitPrice:N2} р / Единица измерения: {material.MeasurementUnit}",
            Font = Theme.CreateFont(9f),
            ForeColor = Theme.TextColor,
            Location = new Point(14, 76),
            Size = new Size(272, 62)
        };
        var requiredLabel = new Label
        {
            Text = $"Требуемое количество: {material.RequiredQuantity:0.00} {material.MeasurementUnit}",
            Font = Theme.CreateFont(9f, FontStyle.Bold),
            ForeColor = Theme.AccentColor,
            Location = new Point(14, 142),
            AutoSize = true
        };

        var productsButton = new Button
        {
            Text = "Продукция с материалом →",
            Size = new Size(190, 28),
            Location = new Point(14, 168),
            Anchor = AnchorStyles.Bottom | AnchorStyles.Left
        };
        Theme.StyleAccentButton(productsButton);
        productsButton.Font = Theme.CreateFont(8.5f, FontStyle.Bold);
        productsButton.Click += (_, _) => OpenProductList(material);

        var editHint = new Label
        {
            Text = "изменить",
            Font = Theme.CreateFont(8f, FontStyle.Italic),
            ForeColor = Theme.AccentColor,
            Location = new Point(222, 174),
            AutoSize = true
        };

        // Клик по карточке (кроме кнопки) — редактирование материала.
        void OpenEditor(object? sender, EventArgs e) => EditMaterial(material);
        foreach (Control control in new Control[] { typeLabel, nameLabel, detailsLabel, requiredLabel, editHint })
        {
            control.Click += OpenEditor;
        }
        card.Click += OpenEditor;

        card.Controls.AddRange([typeLabel, nameLabel, detailsLabel, requiredLabel, productsButton, editHint]);
        PaintCardBorder(card);
        return card;
    }

    private static void PaintCardBorder(Panel card)
    {
        card.Paint += (_, e) =>
        {
            using var path = Theme.RoundedRectangle(new RectangleF(0.5f, 0.5f, card.Width - 2f, card.Height - 2f), 10f);
            using var pen = new Pen(Theme.BorderColor, 1.2f);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.DrawPath(pen, path);
        };
    }

    private void AddMaterial()
    {
        using var form = new MaterialEditForm(null);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            RefreshMaterialList();
        }
    }

    private void EditMaterial(Material material)
    {
        using var form = new MaterialEditForm(material.MaterialId);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            RefreshMaterialList();
        }
    }

    private void OpenProductList(Material material)
    {
        using var form = new ProductListForm(material);
        form.ShowDialog(this);
    }

    /// <summary>Сообщение об ошибке работы с базой данных с рекомендациями по исправлению.</summary>
    internal static void ShowDatabaseError(string action, Exception ex)
    {
        MessageBox.Show(
            $"Не удалось {action}.\n\n" +
            $"Причина: {ex.Message}\n\n" +
            "Проверьте, что служба SQL Server LocalDB запущена и база данных AromaDom создана " +
            "скриптом Database\\CreateAromaDom.sql, затем повторите попытку.",
            "Ошибка базы данных",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }

    private static Image LoadLogo()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Resources", "logo.png");
            return File.Exists(path) ? Image.FromFile(path) : SystemIcons.Application.ToBitmap();
        }
        catch
        {
            return SystemIcons.Application.ToBitmap();
        }
    }

    private static Icon LoadAppIcon()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Resources", "app.ico");
            return File.Exists(path) ? new Icon(path) : SystemIcons.Application;
        }
        catch
        {
            return SystemIcons.Application;
        }
    }
}
