using System.Data;
using AromaDomMaterials.Models;
using Microsoft.Data.SqlClient;

namespace AromaDomMaterials.Data;

/// <summary>
/// Доступ к базе данных подсистемы учёта материалов «Арома Дом» (SQL Server LocalDB).
/// </summary>
public static class AppDatabase
{
    private const string ConnectionString =
        "Server=(localdb)\\MSSQLLocalDB;Database=AromaDom;Trusted_Connection=True;TrustServerCertificate=True;";

    private static SqlConnection OpenConnection()
    {
        var connection = new SqlConnection(ConnectionString);
        connection.Open();
        return connection;
    }

    /// <summary>
    /// Возвращает список материалов с требуемым количеством:
    /// суммой объёма материала по всем продуктам, в рецептуре которых он участвует.
    /// </summary>
    public static List<Material> GetMaterials()
    {
        const string query = """
            SELECT m.MaterialId, m.MaterialTypeId, mt.MaterialTypeName, m.MaterialName,
                   m.UnitPrice, m.MeasurementUnit, m.PackageQuantity, m.StockQuantity,
                   m.MinimumQuantity,
                   CAST(ISNULL(v.RequiredQuantity, 0) AS DECIMAL(12, 2)) AS RequiredQuantity
            FROM dbo.Materials m
            JOIN dbo.MaterialTypes mt ON mt.MaterialTypeId = m.MaterialTypeId
            LEFT JOIN dbo.vw_MaterialsRequired v ON v.MaterialId = m.MaterialId
            ORDER BY mt.MaterialTypeName, m.MaterialName;
            """;

        var materials = new List<Material>();
        using var connection = OpenConnection();
        using var command = new SqlCommand(query, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            materials.Add(new Material
            {
                MaterialId = reader.GetInt32(0),
                MaterialTypeId = reader.GetInt32(1),
                MaterialTypeName = reader.GetString(2),
                MaterialName = reader.GetString(3),
                UnitPrice = reader.GetDecimal(4),
                MeasurementUnit = reader.GetString(5),
                PackageQuantity = reader.GetDecimal(6),
                StockQuantity = reader.GetDecimal(7),
                MinimumQuantity = reader.GetDecimal(8),
                RequiredQuantity = reader.GetDecimal(9)
            });
        }
        return materials;
    }

    /// <summary>Возвращает справочник типов материалов для выпадающего списка.</summary>
    public static List<MaterialType> GetMaterialTypes()
    {
        const string query = "SELECT MaterialTypeId, MaterialTypeName FROM dbo.MaterialTypes ORDER BY MaterialTypeName;";

        var types = new List<MaterialType>();
        using var connection = OpenConnection();
        using var command = new SqlCommand(query, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            types.Add(new MaterialType
            {
                MaterialTypeId = reader.GetInt32(0),
                MaterialTypeName = reader.GetString(1)
            });
        }
        return types;
    }

    /// <summary>Загружает материал по идентификатору для редактирования; null — если не найден.</summary>
    public static Material? GetMaterialById(int materialId)
    {
        const string query = """
            SELECT m.MaterialId, m.MaterialTypeId, mt.MaterialTypeName, m.MaterialName,
                   m.UnitPrice, m.MeasurementUnit, m.PackageQuantity, m.StockQuantity,
                   m.MinimumQuantity,
                   CAST(ISNULL(v.RequiredQuantity, 0) AS DECIMAL(12, 2)) AS RequiredQuantity
            FROM dbo.Materials m
            JOIN dbo.MaterialTypes mt ON mt.MaterialTypeId = m.MaterialTypeId
            LEFT JOIN dbo.vw_MaterialsRequired v ON v.MaterialId = m.MaterialId
            WHERE m.MaterialId = @MaterialId;
            """;

        using var connection = OpenConnection();
        using var command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@MaterialId", materialId);
        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }
        return new Material
        {
            MaterialId = reader.GetInt32(0),
            MaterialTypeId = reader.GetInt32(1),
            MaterialTypeName = reader.GetString(2),
            MaterialName = reader.GetString(3),
            UnitPrice = reader.GetDecimal(4),
            MeasurementUnit = reader.GetString(5),
            PackageQuantity = reader.GetDecimal(6),
            StockQuantity = reader.GetDecimal(7),
            MinimumQuantity = reader.GetDecimal(8),
            RequiredQuantity = reader.GetDecimal(9)
        };
    }

    /// <summary>Добавляет новый материал или обновляет существующий (MaterialId == 0 — добавление).</summary>
    public static void SaveMaterial(Material material)
    {
        const string insertQuery = """
            INSERT INTO dbo.Materials
                (MaterialTypeId, MaterialName, UnitPrice, MeasurementUnit,
                 PackageQuantity, StockQuantity, MinimumQuantity)
            VALUES
                (@MaterialTypeId, @MaterialName, @UnitPrice, @MeasurementUnit,
                 @PackageQuantity, @StockQuantity, @MinimumQuantity);
            """;
        const string updateQuery = """
            UPDATE dbo.Materials
            SET MaterialTypeId = @MaterialTypeId,
                MaterialName = @MaterialName,
                UnitPrice = @UnitPrice,
                MeasurementUnit = @MeasurementUnit,
                PackageQuantity = @PackageQuantity,
                StockQuantity = @StockQuantity,
                MinimumQuantity = @MinimumQuantity
            WHERE MaterialId = @MaterialId;
            """;

        using var connection = OpenConnection();
        using var command = new SqlCommand(material.MaterialId == 0 ? insertQuery : updateQuery, connection);
        command.Parameters.AddWithValue("@MaterialId", material.MaterialId);
        command.Parameters.AddWithValue("@MaterialTypeId", material.MaterialTypeId);
        command.Parameters.AddWithValue("@MaterialName", material.MaterialName);
        command.Parameters.AddWithValue("@UnitPrice", material.UnitPrice);
        command.Parameters.AddWithValue("@MeasurementUnit", material.MeasurementUnit);
        command.Parameters.AddWithValue("@PackageQuantity", material.PackageQuantity);
        command.Parameters.AddWithValue("@StockQuantity", material.StockQuantity);
        command.Parameters.AddWithValue("@MinimumQuantity", material.MinimumQuantity);
        command.ExecuteNonQuery();
    }

    /// <summary>Возвращает список продукции, в рецептуре которой используется материал.</summary>
    public static List<ProductUsage> GetProductsByMaterial(int materialId)
    {
        const string query = """
            SELECT p.Article, p.ProductName, pt.ProductTypeName, mp.QuantityPerUnit
            FROM dbo.MaterialProducts mp
            JOIN dbo.Products p ON p.ProductId = mp.ProductId
            JOIN dbo.ProductTypes pt ON pt.ProductTypeId = p.ProductTypeId
            WHERE mp.MaterialId = @MaterialId
            ORDER BY p.ProductName;
            """;

        var products = new List<ProductUsage>();
        using var connection = OpenConnection();
        using var command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@MaterialId", materialId);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            products.Add(new ProductUsage
            {
                Article = reader.GetString(0),
                ProductName = reader.GetString(1),
                ProductTypeName = reader.GetString(2),
                QuantityPerUnit = reader.GetDecimal(3)
            });
        }
        return products;
    }
}
