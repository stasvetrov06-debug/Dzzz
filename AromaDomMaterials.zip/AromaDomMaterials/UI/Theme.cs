using System.Drawing.Drawing2D;

namespace AromaDomMaterials.UI;

/// <summary>
/// Единый стиль интерфейса согласно «Руководству по стилю» (Приложение 2):
/// шрифт Georgia, основной фон #FFFFFF, дополнительный #F4E6D4, акцент #8A5A44.
/// </summary>
public static class Theme
{
    public static readonly Color PrimaryBackground = Color.White;
    public static readonly Color SecondaryBackground = Color.FromArgb(244, 230, 212); // #F4E6D4
    public static readonly Color AccentColor = Color.FromArgb(138, 90, 68);           // #8A5A44
    public static readonly Color AccentTextColor = Color.White;
    public static readonly Color TextColor = Color.FromArgb(51, 45, 40);
    public static readonly Color BorderColor = Color.FromArgb(214, 196, 178);

    public const string FontFamilyName = "Georgia";

    public static Font CreateFont(float size, FontStyle style = FontStyle.Regular) =>
        new(FontFamilyName, size, style, GraphicsUnit.Point);

    /// <summary>Оформление кнопки основного действия: контрастный акцентный цвет.</summary>
    public static void StyleAccentButton(Button button)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = AccentColor;
        button.ForeColor = AccentTextColor;
        button.Font = CreateFont(10f, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
        button.UseVisualStyleBackColor = false;
    }

    /// <summary>Оформление кнопки возврата «Назад».</summary>
    public static void StyleBackButton(Button button)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderColor = BorderColor;
        button.FlatAppearance.BorderSize = 1;
        button.BackColor = SecondaryBackground;
        button.ForeColor = TextColor;
        button.Font = CreateFont(10f);
        button.Cursor = Cursors.Hand;
        button.UseVisualStyleBackColor = false;
    }

    /// <summary>Закруглённая карточка (для списков в карточном виде).</summary>
    public static GraphicsPath RoundedRectangle(RectangleF bounds, float radius)
    {
        float diameter = radius * 2;
        var arc = new RectangleF(bounds.Location, new SizeF(diameter, diameter));
        var path = new GraphicsPath();
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }
}
