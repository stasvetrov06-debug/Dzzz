using AromaDomMaterials.Data;
using AromaDomMaterials.Models;
using AromaDomMaterials.UI;

namespace AromaDomMaterials;

/// <summary>
/// Форма добавления и редактирования материала: тип (выпадающий список), наименование,
/// цена (до сотых, неотрицательная), единица измерения, количество в упаковке,
/// количество на складе, минимальное количество (неотрицательное).
/// </summary>
public class MaterialEditForm : Form
{
    private readonly int materialId;
    private readonly ComboBox typeComboBox;
    private readonly TextBox nameTextBox;
    private readonly NumericUpDown priceNumeric;
    private readonly TextBox unitTextBox;
    private readonly NumericUpDown packageQuantityNumeric;
    private readonly NumericUpDown stockQuantityNumeric;
    private readonly NumericUpDown minimumQuantityNumeric;

    public MaterialEditForm(int? materialId)
    {
        this.materialId = materialId ?? 0;
        bool isEdit = materialId.HasValue;

        Text = isEdit ? "Редактирование материала" : "Добавление материала";
        ClientSize = new Size(480, 470);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Theme.PrimaryBackground;
        Font = Theme.CreateFont(10f);
        Icon = FormIconLoader.Load();

        var headerLabel = new Label
        {
            Text = isEdit ? "Редактирование данных о материале" : "Новые данные о материале",
            Font = Theme.CreateFont(12f, FontStyle.Bold),
            ForeColor = Theme.AccentColor,
            Location = new Point(20, 18),
            AutoSize = true
        };

        // ---------- Поля формы ----------
        var typeLabel = CreateFieldLabel("Тип материала:", 20, 62);
        typeComboBox = new ComboBox
        {
            Location = new Point(20, 82),
            Size = new Size(440, 26),
            DropDownStyle = ComboBoxStyle.DropDownList,
            Font = Theme.CreateFont(10f)
        };

        var nameLabel = CreateFieldLabel("Наименование:", 20, 118);
        nameTextBox = new TextBox
        {
            Location = new Point(20, 138),
            Size = new Size(440, 26),
            Font = Theme.CreateFont(10f),
            MaxLength = 150
        };

        var priceLabel = CreateFieldLabel("Цена единицы материала, р (до сотых, не менее 0):", 20, 174);
        priceNumeric = CreateNumericUpDown(20, 194, decimals: 2, maximum: 1_000_000m);

        var unitLabel = CreateFieldLabel("Единица измерения:", 20, 230);
        unitTextBox = new TextBox
        {
            Location = new Point(20, 250),
            Size = new Size(440, 26),
            Font = Theme.CreateFont(10f),
            MaxLength = 20
        };

        var packageQuantityLabel = CreateFieldLabel("Количество в упаковке:", 20, 286);
        packageQuantityNumeric = CreateNumericUpDown(20, 306, decimals: 3, maximum: 1_000_000m);

        var stockQuantityLabel = CreateFieldLabel("Количество на складе:", 250, 286);
        stockQuantityNumeric = CreateNumericUpDown(250, 306, decimals: 3, maximum: 1_000_000m);

        var minimumQuantityLabel = CreateFieldLabel("Минимальное количество (не менее 0):", 20, 342);
        minimumQuantityNumeric = CreateNumericUpDown(20, 362, decimals: 3, maximum: 1_000_000m);

        // ---------- Кнопки ----------
        var saveButton = new Button
        {
            Text = "Сохранить",
            Size = new Size(210, 40),
            Location = new Point(250, 410)
        };
        Theme.StyleAccentButton(saveButton);
        saveButton.Click += (_, _) => SaveMaterial();

        var backButton = new Button
        {
            Text = "← Назад",
            Size = new Size(210, 40),
            Location = new Point(20, 410)
        };
        Theme.StyleBackButton(backButton);
        backButton.Click += (_, _) =>
        {
            if (HasUnsavedChanges())
            {
                DialogResult answer = MessageBox.Show(
                    "Есть несохранённые изменения. Закрыть форму без сохранения?",
                    "Предупреждение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);
                if (answer != DialogResult.Yes)
                {
                    return;
                }
            }
            DialogResult = DialogResult.Cancel;
            Close();
        };

        Controls.AddRange([
            headerLabel, typeLabel, typeComboBox, nameLabel, nameTextBox,
            priceLabel, priceNumeric, unitLabel, unitTextBox,
            packageQuantityLabel, packageQuantityNumeric,
            stockQuantityLabel, stockQuantityNumeric,
            minimumQuantityLabel, minimumQuantityNumeric,
            saveButton, backButton
        ]);

        // Подгрузка данных выбранного объекта в поля при открытии формы редактирования.
        Load += (_, _) => LoadData(isEdit);
        AcceptButton = saveButton;
        CancelButton = backButton;
    }

    /// <summary>Загружает справочник типов и — при редактировании — значения материала.</summary>
    private void LoadData(bool isEdit)
    {
        try
        {
            List<MaterialType> types = AppDatabase.GetMaterialTypes();
            if (types.Count == 0)
            {
                MessageBox.Show(
                    "Справочник типов материалов пуст. Сначала добавьте тип материала в базу данных.",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                DialogResult = DialogResult.Cancel;
                Close();
                return;
            }

            typeComboBox.DataSource = types;
            typeComboBox.DisplayMember = nameof(MaterialType.MaterialTypeName);
            typeComboBox.ValueMember = nameof(MaterialType.MaterialTypeId);

            if (isEdit)
            {
                Material? material = AppDatabase.GetMaterialById(materialId);
                if (material is null)
                {
                    MessageBox.Show(
                        "Материал не найден в базе данных. Возможно, он был удалён другим пользователем.\n" +
                        "Форма будет закрыта, список материалов обновится.",
                        "Материал не найден",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Cancel;
                    Close();
                    return;
                }
                typeComboBox.SelectedValue = material.MaterialTypeId;
                nameTextBox.Text = material.MaterialName;
                priceNumeric.Value = material.UnitPrice;
                unitTextBox.Text = material.MeasurementUnit;
                packageQuantityNumeric.Value = material.PackageQuantity;
                stockQuantityNumeric.Value = material.StockQuantity;
                minimumQuantityNumeric.Value = material.MinimumQuantity;
            }
        }
        catch (Exception ex)
        {
            MainForm.ShowDatabaseError("не удалось загрузить данные формы", ex);
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }

    /// <summary>Проверяет введённые данные и сохраняет материал в базу данных.</summary>
    private void SaveMaterial()
    {
        // Визуальные подсказки: сброс цвета ввода перед проверкой.
        nameTextBox.BackColor = Theme.PrimaryBackground;
        unitTextBox.BackColor = Theme.PrimaryBackground;
        typeComboBox.BackColor = Theme.PrimaryBackground;

        var errors = new List<string>();

        int? selectedTypeId = typeComboBox.SelectedValue as int?;
        if (selectedTypeId is null or <= 0)
        {
            errors.Add("• Выберите тип материала из выпадающего списка.");
            typeComboBox.BackColor = Color.MistyRose;
        }
        if (string.IsNullOrWhiteSpace(nameTextBox.Text))
        {
            errors.Add("• Укажите наименование материала.");
            nameTextBox.BackColor = Color.MistyRose;
        }
        if (string.IsNullOrWhiteSpace(unitTextBox.Text))
        {
            errors.Add("• Укажите единицу измерения материала.");
            unitTextBox.BackColor = Color.MistyRose;
        }
        if (priceNumeric.Value < 0)
        {
            errors.Add("• Цена единицы материала не может быть отрицательной.");
        }
        if (minimumQuantityNumeric.Value < 0)
        {
            errors.Add("• Минимальное количество не может быть отрицательным.");
        }

        if (errors.Count > 0)
        {
            MessageBox.Show(
                "Не удалось сохранить материал из-за ошибок заполнения формы:\n\n" +
                string.Join("\n", errors) +
                "\n\nИсправьте выделенные поля и нажмите «Сохранить» ещё раз.",
                "Ошибка заполнения",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        var material = new Material
        {
            MaterialId = materialId,
            MaterialTypeId = selectedTypeId ?? 0,
            MaterialName = nameTextBox.Text.Trim(),
            UnitPrice = decimal.Round(priceNumeric.Value, 2),
            MeasurementUnit = unitTextBox.Text.Trim(),
            PackageQuantity = packageQuantityNumeric.Value,
            StockQuantity = stockQuantityNumeric.Value,
            MinimumQuantity = decimal.Round(minimumQuantityNumeric.Value, 3)
        };

        try
        {
            AppDatabase.SaveMaterial(material);
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
        {
            // Нарушение уникального ограничения наименования материала.
            MessageBox.Show(
                "Материал с таким наименованием уже существует в базе данных.\n" +
                "Укажите уникальное наименование и повторите сохранение.",
                "Конфликт данных",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            nameTextBox.BackColor = Color.MistyRose;
            return;
        }
        catch (Exception ex)
        {
            MainForm.ShowDatabaseError("не удалось сохранить материал", ex);
            return;
        }

        MessageBox.Show(
            $"Данные материала «{material.MaterialName}» успешно сохранены.",
            "Сохранение выполнено",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
        DialogResult = DialogResult.OK;
        Close();
    }

    /// <summary>Признак несохранённых изменений — для предупреждения при закрытии.</summary>
    private bool HasUnsavedChanges()
    {
        if (materialId != 0)
        {
            return false; // при редактировании сравнивать значения избыточно для учебного задания
        }
        return !string.IsNullOrWhiteSpace(nameTextBox.Text) || !string.IsNullOrWhiteSpace(unitTextBox.Text);
    }

    private static Label CreateFieldLabel(string text, int x, int y) => new()
    {
        Text = text,
        Font = Theme.CreateFont(9f),
        ForeColor = Theme.TextColor,
        Location = new Point(x, y),
        AutoSize = true
    };

    private static NumericUpDown CreateNumericUpDown(int x, int y, int decimals, decimal maximum) => new()
    {
        Location = new Point(x, y),
        Size = new Size(210, 26),
        Font = Theme.CreateFont(10f),
        DecimalPlaces = decimals,
        Maximum = maximum,
        Minimum = 0,
        ThousandsSeparator = true
    };
}

/// <summary>Загрузка иконки приложения для вспомогательных форм.</summary>
internal static class FormIconLoader
{
    public static Icon Load()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Resources", "app.ico");
            return File.Exists(path) ? new Icon(path) : SystemIcons.Application;
        }
        catch
        {
            return SystemIcons.Application;
        }
    }
}
