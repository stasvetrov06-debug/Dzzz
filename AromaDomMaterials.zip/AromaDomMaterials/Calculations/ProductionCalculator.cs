using Microsoft.Data.SqlClient;

namespace AromaDomMaterials.Calculations;

/// <summary>
/// Расчёт количества продукции, получаемой из заданного количества сырья, с учётом потерь.
/// </summary>
public static class ProductionCalculator
{
    /// <summary>
    /// Вычисляет целое количество продукции, получаемой из заданного количества сырья, с учётом потерь.
    /// Сырьё на единицу продукции = параметр1 × параметр2 × коэффициент типа продукции.
    /// Учитывается процент потери сырья типа материала: итоговое количество продукции уменьшается.
    /// </summary>
    /// <param name="productTypeId">Идентификатор типа продукции.</param>
    /// <param name="materialTypeId">Идентификатор типа материала (сырья).</param>
    /// <param name="rawQuantity">Количество сырья (целое, неотрицательное).</param>
    /// <param name="productParameter1">Первый параметр продукции (вещественный, положительный).</param>
    /// <param name="productParameter2">Второй параметр продукции (вещественный, положительный).</param>
    /// <returns>Количество получаемой продукции; -1 — если входные данные некорректны.</returns>
    public static int CalculateProductQuantity(
        int productTypeId,
        int materialTypeId,
        int rawQuantity,
        double productParameter1,
        double productParameter2)
    {
        // Неподходящие данные: несуществующие типы или неотрицательные/неположительные параметры.
        if (productTypeId <= 0 || materialTypeId <= 0 || rawQuantity < 0 ||
            productParameter1 <= 0 || productParameter2 <= 0)
        {
            return -1;
        }

        decimal? coefficient = GetProductTypeCoefficient(productTypeId);
        decimal? lossPercent = GetMaterialTypeLossPercent(materialTypeId);
        if (coefficient is null or <= 0 || lossPercent is null or < 0)
        {
            return -1;
        }

        // Сырьё на одну единицу продукции с учётом коэффициента типа продукции.
        double rawPerUnit = productParameter1 * productParameter2 * (double)coefficient.Value;

        // LossPercent хранится в долях (например, 0.12 — это 12% потерь),
        // поэтому коэффициент потерь применяется напрямую: 1 + 0.12 = 1.12.
        // Чем выше потери, тем больше сырья нужно на единицу и тем меньше продукции получается.
        double rawPerUnitWithLosses = rawPerUnit * (1 + (double)lossPercent.Value);

        if (rawPerUnitWithLosses <= 0 || double.IsNaN(rawPerUnitWithLosses) || double.IsInfinity(rawPerUnitWithLosses))
        {
            return -1;
        }

        return (int)(rawQuantity / rawPerUnitWithLosses);
    }

    private static decimal? GetProductTypeCoefficient(int productTypeId)
    {
        const string query = "SELECT Coefficient FROM dbo.ProductTypes WHERE ProductTypeId = @ProductTypeId;";
        return ExecuteScalarDecimal(query, "@ProductTypeId", productTypeId);
    }

    private static decimal? GetMaterialTypeLossPercent(int materialTypeId)
    {
        const string query = "SELECT LossPercent FROM dbo.MaterialTypes WHERE MaterialTypeId = @MaterialTypeId;";
        return ExecuteScalarDecimal(query, "@MaterialTypeId", materialTypeId);
    }

    private static decimal? ExecuteScalarDecimal(string query, string parameterName, int parameterValue)
    {
        try
        {
            using var connection = new SqlConnection(
                "Server=(localdb)\\MSSQLLocalDB;Database=AromaDom;Trusted_Connection=True;TrustServerCertificate=True;");
            connection.Open();
            using var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue(parameterName, parameterValue);
            var result = command.ExecuteScalar();
            return result is decimal value ? value : null;
        }
        catch (SqlException)
        {
            return null;
        }
    }
}
