using System.Windows.Forms;

namespace AromaDomMaterials;

/// <summary>
/// Точка входа приложения «Арома Дом — Учёт материалов».
/// </summary>
internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Глобальная обработка непредвиденных исключений: приложение не завершается аварийно,
        // а показывает пользователю информативное сообщение об ошибке.
        Application.ThreadException += (_, e) => ShowUnexpectedError(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            ShowUnexpectedError(e.ExceptionObject as Exception ?? new Exception("Неизвестная ошибка."));

        Application.Run(new MainForm());
    }

    private static void ShowUnexpectedError(Exception ex)
    {
        MessageBox.Show(
            "В приложении возникла непредвиденная ошибка и оно не может продолжить работу.\n\n" +
            $"Технические сведения: {ex.Message}\n\n" +
            "Пожалуйста, перезапустите приложение. Если ошибка повторяется, обратитесь к администратору.",
            "Непредвиденная ошибка",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}
